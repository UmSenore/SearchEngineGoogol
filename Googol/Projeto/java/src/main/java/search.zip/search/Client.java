package search;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.rmi.registry.LocateRegistry;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Client {
    public static void main(String[] args) {
        try {
            Index index = (Index) LocateRegistry.getRegistry(8183).lookup("index");

            Scanner scan = new Scanner(System.in);
            String input;

            while (true) {
                System.out.println("Server ready. Waiting for input...");

                //TODO: This approach needs to become interactive. Use a Scanner(System.in) to create a rudimentary user interface to:

                input = scan.nextLine();
                String[] url_begin = input.split(":");
                if (url_begin[0].equals("https") || url_begin[0].equals("http")) {
                    //1. Add urls for indexing
                    index.putNew(input);
                } else {
                    //2. search indexed urls
                    ArrayList<String> retrieved_urls = index.searchWord(input);
                    System.out.println("{");
                    for (String url : retrieved_urls) {
                        System.out.println(url + " ");
                        // deixar bonito
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
