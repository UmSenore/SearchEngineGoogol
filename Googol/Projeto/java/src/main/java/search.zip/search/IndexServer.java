package search;

import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.util.concurrent.*;
import java.io.*;
import java.util.*;

public class IndexServer extends UnicastRemoteObject implements Index {
    private Stack<String> urlsToIndex;
    private ConcurrentHashMap<String, ArrayList<String>> indexedItems;
    private Set<String> seenUrls;
    // < !!! > Perguntar ao professor qual a melhor maneira de impedir o loop
    // e se fosse por exemplo ao adicionar prioridades aos links, se punhamos os links já visitados no fim da stack?
    public IndexServer() throws RemoteException {
        super();
        //This structure has a number of problems. The first is that it is fixed size. Can you enumerate the others?
        urlsToIndex = new Stack<String>();
        indexedItems = new ConcurrentHashMap<String, ArrayList<String>>();
        seenUrls  = new HashSet<>();
    }

    public static void main(String args[]) {
        try {
            IndexServer server = new IndexServer();
            Registry registry = LocateRegistry.createRegistry(8183);
            registry.rebind("index", server);

            Scanner scan = new Scanner(System.in);
            String input;

            while (true) {
                System.out.println("Server ready. Waiting for input...");

                //TODO: This approach needs to become interactive. Use a Scanner(System.in) to create a rudimentary user interface to:

                input = scan.nextLine();
                String[] url_begin = input.split(":");
                if (url_begin[0].equals("https") || url_begin[0].equals("http")) {
                    //1. Add urls for indexing
                    server.putNew(input);
                } else {
                    //2. search indexed urls
                    ArrayList<String> retrieved_urls = server.searchWord(input);
                    System.out.println("{");
                    for (String url : retrieved_urls) {
                        System.out.println(url + " ");
                        // deixar bonito
                    }
                }
            }

        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    private long counter = 0, timestamp = System.currentTimeMillis();;

    public String takeNext() throws RemoteException {
        //TODO: not implemented fully. Prefer structures that return in a push/pop fashion
        return urlsToIndex.pop();
    }

    public void putNew(String url) throws java.rmi.RemoteException {
        //TODO: Example code. Must be changed to use structures that have primitives such as .add(...)
        if (seenUrls.contains(url)) {
            return;
        }
        seenUrls.add(url);
        urlsToIndex.push(url);
    }

    public void addToIndex(String word, String url) throws java.rmi.RemoteException {
        //TODO: not implemented
        if (indexedItems.containsKey(word)) {
            if (indexedItems.get(word).contains(url)) {
                return;
            }
            indexedItems.get(word).add(url);
        } else {
            ArrayList<String> temp = new ArrayList<>();
            temp.add(url);
            indexedItems.put(word, temp);
        }
    }

    public ArrayList<String> searchWord(String word) throws java.rmi.RemoteException {
        //TODO: not implemented
        return indexedItems.get(word);
    }

    public Set<String> retrieveSeenUrls() throws java.rmi.RemoteException {
        // < !!! > Perguntar o que o professor entende por monitoring indexing progress and statistics
        return seenUrls;
    }
}
